<?php
	$dbhost = "localhost";
	$dbuser = "id803784_dbadmin";
	$dbpassword = "password";
	$dbdatabase = "id803784_qu1701b_38_t0044045g_ecart";
		
	$db = mysql_connect($dbhost, $dbuser, $dbpassword);
	mysql_select_db($dbdatabase, $db);
		
	$sql ="SELECT * FROM categories";	
	$resultRow = mysql_query($sql);

	$categories = Array();
	while ($item = mysql_fetch_object($resultRow) )
	{
		array_push ($categories, $item);	
	}

   //Variables to store the HTML Control values
   $name = "";
   $imagePath = "";
   $price = "";
   $categoryID = "";
   $description = "";
	
   $isClicked = isset($_POST["btnSubmit"]);
   //If user has clicked on Save Button
   if($isClicked == true) {
		$name = $_POST["tbName"];
		$imagePath = $_POST["imagePath"];
		
		$image_file = $_FILES["image_file"];
		$image_file_name = $image_file["name"];
		
		$isValidInput = true;
		//Required Field Validation
		if(isempty($name) == true) {
			$isValidInput = false;
		}
		
		//Only processed when the input is valid
		if($isValidInput) {
			if($image_file_name != "") {
				$sourceImageFileName = $image_file["tmp_name"];
				$targetImageFilePath = "images/" . $image_file["name"];
				
				//Move uploaded temporary file to target image folder
				move_uploaded_file($sourceImageFileName, $targetImageFilePath);
				$imagePath = "/40_kevin" . "/images/" . $image_file_name;
			}
			$price = $_POST['price'];
			$categoryID = $_POST['category'];
					
			$description = $_POST['description'];
			
			$sql = "INSERT INTO products(cat_id,name,description,image_path,price)" .
				   "VALUES("  . $categoryID . "," . "'" . $name . "'" .
						   "," . "'" . addslashes($description) . "'" . "," . "'" . $imagePath . "'" .
						   "," . "'" . $price . "'" .
				   ")";
			
			mysql_query($sql);
			header("location:productlisting.php");
		}
   }
  
  //Common Field Validation Functions
	function isempty($value) {
		$value = trim($value);
		if(empty($value)) {
			return true;
		}
		else {
			return false;
		}	
	}
	function requiredField($name) {
		//Only VALIDATE when user has clicked the button
		$isClicked = isset($_POST["btnSubmit"]);
		if($isClicked == true){
			$value = $_POST[$name];
			if(isempty($value) == true) {
				echo "<span style='color:red'>This is required</span>";
			}
		}
	}
?>
<?php 
	include("header.php");
?>
 <div id="main">
	<div>
	   <h2>Edit Product</h2>
	</div>
	<div>
		<form action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="POST" enctype="multipart/form-data">
			<table class="table">
				<tr>
					<td>
						Name
					</td>	
					<td>
						<input type="text" name="tbName" id="tbName" value="<?php echo $name; ?>">
						</input>
						<?php
							requiredField("tbName");
						?>
					</td>
				</tr>
				<tr>
					<td>Description</td>
					<td>
						<textarea  style="height:100px;width:500px;" name="description"></textarea>
					</td>
				</tr>
				<tr>
					<td>Price</td>
					<td>
						<input type="text" name="price" class="input-small"></input>
					</td>
				</tr>
				<tr>
					<td>Category</td>
					<td>
						<select name="category" class="span2">
							<option value="">Select</option>
							<?php
								$length = count($categories);
								for($i=0;$i<$length;$i++) {
									$category = $categories[$i];
									echo "<option value=" . "'" . $category->id . "'" . ">" . $category->name . "</option>";
								}
							?>
							
						</select>
				
					</td>
				</tr>
				<tr>
					<td>
						Image File
					</td>	
					<td>
						<input type="file" name="image_file"></input>
						<?php
						  if($imagePath != "") {
							  echo "<br/>";
							  echo "<img src='" . $imagePath . "' alt=''/>";
						  }
						?>
					</td>
				</tr>
				<tr>
					<td>
						
					</td>	
					<td>
						<input type="submit" name="btnSubmit" id="btnSubmit" value="Save">
						</input>
					</td>
				</tr>
			</table>
			<input type="hidden" name="imagePath" value="<?php echo $imagePath; ?>" ></input>
		</form>
	</div>
</div>
<?php 
	include("footer.php");
?>