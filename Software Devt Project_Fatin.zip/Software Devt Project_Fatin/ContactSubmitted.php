<?php 
	include("header.php");
?>
 <div id="main">
	<div>
	   <h2>Form Submitted</h2>
	</div>
	<div>
		Thank you for contacting us. We will be in touch with you very soon.
	</div>
</div>
<?php 
	include("footer.php");
?>