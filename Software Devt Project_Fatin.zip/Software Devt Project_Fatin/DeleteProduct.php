<?php
	$dbhost = "localhost";
	$dbuser = "id803784_dbadmin";
	$dbpassword = "password";
	$dbdatabase = "id803784_qu1701b_38_t0044045g_ecart";
		
	$db = mysql_connect($dbhost, $dbuser, $dbpassword);
	mysql_select_db($dbdatabase, $db);
		
	$id = $_GET["id"];
	$sql = "DELETE FROM products WHERE id=" . $id;
	mysql_query($sql);
	
	header("location:productlisting.php");
?>
