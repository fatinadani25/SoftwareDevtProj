<?php
 	$dbhost = "localhost";
	$dbuser = "id803784_dbadmin";
	$dbpassword = "password";
	$dbdatabase = "id803784_qu1701b_38_t0044045g_ecart";
		
  $db = mysql_connect($dbhost, $dbuser, $dbpassword);
  mysql_select_db($dbdatabase, $db);
		
  //Variables to store the textboxes values
  $name = "";
  $description = "";
   
  $isClicked = isset($_POST["btnSubmit"]);
  //If user has clicked on Save Button
  if($isClicked == true) {
	//Get the ID from Url from GET
	$id = $_GET["id"];
	
	//Get user's input from  $_POST form and update database
	$name = $_POST["tbName"];
	$description = $_POST["tbDescription"];
	
	$isValidInput = true;
	//Required Field Validation
	if(isempty($name) == true) {
		$isValidInput = false;
	}
	
	//Only processed when the input is valid
	if($isValidInput) {
		$sql = "UPDATE categories SET name='" . $name . "'" . " WHERE id=" . $id;
		mysql_query($sql);
		header("location:categorylisting.php");
	}
  }
  else { //First time page is loading, no button is clicked
  
	  //To check Query String ID exists, if not redirect to accessdenied.php
	  $hasIDKey = isset($_GET["id"]);
	  if($hasIDKey == false) {
		  header("location: accessdenied.php");
	  }
	  
	  //Load the record from database based on Query String ID
	  $id = $_GET["id"];
	  
	  $sql = "SELECT * FROM categories WHERE id=" . $id;
	  $result = mysql_query($sql);
	  $obj = mysql_fetch_object( $result ); 
	  $name = $obj->name;
  }
  
  //Common Field Validation Functions
	function isempty($value) {
		$value = trim($value);
		if(empty($value)) {
			return true;
		}
		else {
			return false;
		}	
	}
	function requiredField($name) {
		//Only VALIDATE when user has clicked the Register button
		$isClicked = isset($_POST["btnSubmit"]);
		if($isClicked == true){
			$value = $_POST[$name];
			if(isempty($value) == true) {
				echo "<span style='color:red'>This is required</span>";
			}
		}
	}
  
?>
<?php 
	include("header.php");
?>
  <div id="main">
	<div>
	   <h2>Categories</h2>
	</div>
	<div>
		<form action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="POST">
			<table class="table">
				<tr>
					<td>
						Name
					</td>	
					<td>
						<input type="text" name="tbName" id="tbName" value="<?php echo $name; ?>">
						</input>
						<?php
							requiredField("tbName");	
						?>
					</td>
				</tr>
				<tr>
					<td>
						Description
					</td>	
					<td>
						<textarea  rows="5" cols="40" name="tbDescription" id="tbDescription"><?php echo $description; ?></textarea>
					</td>
				</tr>
				<tr>
					<td>
						
					</td>	
					<td>
						<input type="submit" name="btnSubmit" id="btnSubmit" value="Save">
						</input>
					</td>
				</tr>
			</table>
	</div>
  </div>
<?php 
	include("footer.php");
?>

