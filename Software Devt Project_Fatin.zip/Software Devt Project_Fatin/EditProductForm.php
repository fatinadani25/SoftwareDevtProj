<?php
	$dbhost = "localhost";
	$dbuser = "id803784_dbadmin";
	$dbpassword = "password";
	$dbdatabase = "id803784_qu1701b_38_t0044045g_ecart";
		
	$db = mysql_connect($dbhost, $dbuser, $dbpassword);
	mysql_select_db($dbdatabase, $db);
	
	$id = "";
	$name = "";
	$price = "";
	$categoryID = "";
	$description = "";
	$imagePath = "";
	
	$sql ="SELECT * FROM categories";	
	$resultRow = mysql_query($sql);

	$categories = Array();
	while ($item = mysql_fetch_object($resultRow) )
	{
		array_push ($categories, $item);	
	}
	
	$isSaveButtonClick = isset($_POST["save"]); //When submit button is clicked
	if($isSaveButtonClick == true) { 
		$id = $_GET["id"];
		$price = $_POST['price'];
		$categoryID = $_POST['category'];
				
		$name = $_POST["name"];
		$description = $_POST['description'];
		
		$file = $_FILES["image_file"];
		
		$imagePath = $_POST['imagePath'];
		
		if($file["name"] != "") {
			$sourceImageFileName = $file["tmp_name"];
			$targetImageFilePath = "images/" . $file["name"];
			
			move_uploaded_file($sourceImageFileName,$targetImageFilePath);
			$imagePath = "/40_kevin" . "/images/" . $file["name"];
		}
		
		$sql = "UPDATE products SET " .
               "name = " . "'" . $name . "'" . "," . " " .
			   "description = " . "'" . $description . "'" . "," . " " .
			   "image_path = " . "'" . $imagePath . "'" . "," . " " .
			   "price = " . "'" . $price . "'" . "," . " " .
			   "cat_id = " . $categoryID  . " " .
			   "WHERE id=" . $id;
		
		mysql_query($sql);
		header("location:productlisting.php");
	}
	else { //First time loading
		$id = $_GET["id"];
		$sql = "SELECT * FROM products WHERE id=" . $id;
		$result = mysql_query($sql);
		$obj = mysql_fetch_object( $result ); 
	    $name = $obj->name;
		$price = $obj->price;
		$categoryID = $obj->cat_id;
		$description = $obj->description;
		$imagePath = $obj->image_path;
	}
	
	function isempty($value) {
		$value = trim($value);
		if(empty($value)) {
			return true;
		}
		else {
			return false;
		}
	}
	function requiredField($name) {
		$isClicked = isset($_POST["save"]);
		if($isClicked == true){
			$value = $_POST[$name];
			if(isempty($value) == true) {
				echo "<span style='color:red'>This is required</span>";
			}
		}
	}
?>
<?php 
	include("header.php");
?>
 <div id="main">
	<div>
	   <h2>Edit Product</h2>
	</div>
	<div>
		<form method="POST" action="<?php echo $_SERVER['REQUEST_URI']; ?>" enctype="multipart/form-data">
			<table class="table">
				<tr>
					<td>Name</td>
					<td>
						<input type="text" name="name" value="<?php echo $name; ?>"></input>
						<?php requiredField("name"); ?>
					</td>
				</tr>
				<tr>
					<td>Description</td>
					<td>
						<textarea  style="height:100px;width:500px;" name="description" ><?php echo $description; ?></textarea>
					</td>
				</tr>
				<tr>
					<td>Price</td>
					<td>
						<input type="text" name="price" class="input-small" value="<?php echo $price; ?>"></input>
					</td>
				</tr>
				<tr>
					<td>Category</td>
					<td>
						<select name="category" class="span2">
							<option value="">Select</option>
							<?php
								$length = count($categories);
								for($i=0;$i<$length;$i++) {
									$category = $categories[$i];
									$selected = "";
									if($categoryID == $category->id) {
										 $selected = "selected";
									}
									echo "<option " . $selected . " value=" . "'" . $category->id . "'" . ">" . $category->name . "</option>";
								}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td>Image File</td>
					<td>
						<?php
							  if($imagePath != "") {
								  echo "<img src='" . $imagePath . "' alt=''/>";
							 }
						?>
						<input type="file" name="image_file"></input>
					</td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="save" value="Save" class="btn btn-info"></input></td>
				</tr>
			</table>
			<input type="hidden" name="imagePath" value="<?php echo $imagePath; ?>" ></input>
		</form>
	</div>
</div>
<?php 
	include("footer.php");
?>