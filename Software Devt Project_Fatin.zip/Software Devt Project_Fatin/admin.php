<?php 
	include("header.php");
?>
 <div id="main">
	<div>
	   <h2>Admin</h2>
	   <hr/>
	</div>
	<div>
		<div>
			<a href="categorylisting.php" title="Manage Categories">Manage Categories</a>
		</div>
		<div>
			<a href="productlisting.php" title="Manage Products">Manage Products</a>
		</div>
	</div> 
 </div>
<?php 
	include("footer.php");
?>

