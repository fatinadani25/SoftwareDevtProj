<?php
	$dbhost = "localhost";
	$dbuser = "id803784_dbadmin";
	$dbpassword = "password";
	$dbdatabase = "id803784_qu1701b_38_t0044045g_ecart";
	
	$db = mysql_connect($dbhost, $dbuser, $dbpassword);
	mysql_select_db($dbdatabase, $db);
	
	$sql = "SELECT * FROM categories";
	$resultRow = mysql_query($sql);
	
	$categories = Array();
	while($item = mysql_fetch_object($resultRow) ){
		array_push(	$categories,$item);
	}

	$isAddCategoryButtonClicked = isset($_POST["addCategory"]);
	if($isAddCategoryButtonClicked == true) {
		header("location: AddCategoryForm.php");
	}
?>
<?php 
	include("header.php");
?>
  <div id="main">
	<div>
	   <h2>Categories</h2>
	</div>
	<div>
		<form method="POST" action="categorylisting.php">
			<input type="submit" name="addCategory" value="Add Category"></input>
		</form>
		<table class="table table-bordered">
			<tr>
				<th>
					Name
				</th>
				<th>
					
				</th>
				<th>
					
				</th>
			</tr>
			<?php
			    $totalSize = count($categories);
				for($i=0; $i < $totalSize; $i++) {
					$category = $categories[$i];
					echo "<tr>" . "\n";
					echo "\t  <td>" . "\n";
					echo "\t    " . $category->name . "\n";
					echo "\t  </td>" . "\n";
					echo "\t	<td>" . "\n";
					echo "\t		<a href='EditCategoryForm.php?id=" . $category->id . "'" . ">" . "Edit" . "</a>" . "\n";
					echo "\t	</td>" . "\n";
					echo "\t	<td>" . "\n";
					echo "\t		<a href='DeleteCategory.php?id=" . $category->id . "'" . ">" . "Delete" . "</a>" . "\n";
					echo "\t	</td>" . "\n";
					echo "\t</tr>" . "\n";
				}
			?>
		</table>
	 </div>
  </div>
<?php 
	include("footer.php");
?>
	 