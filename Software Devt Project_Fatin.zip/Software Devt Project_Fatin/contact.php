<?php
	$dbhost = "localhost";
	$dbuser = "id803784_dbadmin";
	$dbpassword = "password";
	$dbdatabase = "id803784_qu1701b_38_t0044045g_ecart";
		
	$db = mysql_connect($dbhost, $dbuser, $dbpassword);
	mysql_select_db($dbdatabase, $db);
		
	$sql ="SELECT * FROM categories";	
	$resultRow = mysql_query($sql);

	$categories = Array();
	while ($item = mysql_fetch_object($resultRow) )
	{
		array_push ($categories, $item);	
	}

   //Variables to store the HTML Control values
   $firstName = "";
   $lastName = "";
   $email = "";
   $contactNo = "";
   $comments = "";
   $subject = "";
	
   $isClicked = isset($_POST["btnSubmit"]);
   //If user has clicked on Save Button
   if($isClicked == true) {
		$firstName = $_POST["first_name"];
		$lastName = $_POST["last_name"];
		$email = $_POST["email"];
		$contactNo = $_POST["telephone"];
		$comments = $_POST["comments"];
		$subject = $_POST["subject"];
		
		$isValidInput = true;
		//Required Field Validation
		if(isempty($firstName) == true ||
		   isempty($lastName) == true ||
		   isempty($email) == true ||
		   isempty($contactNo) == true ||
		   isempty($subject) == true
		) {
			$isValidInput = false;
		}
		
		//Only processed when the input is valid
		if($isValidInput) {
			$email_message = "Form details below.\n\n";
			$email_message .= "First Name: " . $firstName . "\n";
			$email_message .= "Last Name: " . $lastName . "\n";
			$email_message .= "Email: " . $email . "\n";
			$email_message .= "Contact No: " . $contactNo . "\n";
			$email_message .= "Comments: " . $comments . "\n";
			$from = "noreply@femalefootwear.com";
			$to = "yap_wei_leong@ite.edu.sg";
			
			$headers = 'From: ' . $from . "\r\n".
			'Reply-To: ' . $email ."\r\n" .
			'X-Mailer: PHP/' . phpversion();

			mail($to,$subject,$email_message,$headers);
	
			header("location:ContactSubmitted.php");
		}
   }
  
  //Common Field Validation Functions
	function isempty($value) {
		$value = trim($value);
		if(empty($value)) {
			return true;
		}
		else {
			return false;
		}	
	}
	function requiredField($name) {
		//Only VALIDATE when user has clicked the button
		$isClicked = isset($_POST["btnSubmit"]);
		if($isClicked == true){
			$value = $_POST[$name];
			if(isempty($value) == true) {
				echo "<span style='color:red'>This is required</span>";
			}
		}
	}
?>
<?php 
	include("header.php");
?>
 <div id="main">
	<div>
	   <h2>Contact Us</h2>
	</div>
	<div>
		<form action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="POST">
			<table class="table">
				<tr>
				 <td>
				  First Name *
				 </td>
				 <td>
				  <input type="text" name="first_name" maxlength="50" size="30">
				  <?php
					requiredField("first_name");
				  ?>
				 </td>
				</tr>
				<tr>
				 <td>
				   Last Name *
				 </td>
				 <td >
				  <input  type="text" name="last_name" maxlength="50" size="30">
				   <?php
					requiredField("last_name");
				  ?>
				 </td>
				</tr>
				<tr>
				 <td>
				  Email Address *
				 </td>
				 <td >
				  <input  type="text" name="email" maxlength="80" size="30">
				   <?php
					requiredField("email");
				  ?>
				 </td>
				</tr>
				<tr>
				 <td>
				  Contact Number
				 </td>
				 <td >
				  <input type="text" name="telephone" maxlength="30" size="30">
				   <?php
					requiredField("telephone");
				  ?>
				 </td>
				</tr>
				<tr>
				 <td>
				  Subject *
				 </td>
				 <td>
				  <input type="text" name="subject" maxlength="30" size="30">
				   <?php
					requiredField("subject");
				  ?>
				 </td>
				</tr>
				<tr>
				 <td>
				  Comments *
				 </td>
				 <td>
				  <textarea  name="comments" maxlength="1000" cols="28" rows="3"></textarea>
				 </td>
				</tr>
				<tr>
				 <td colspan="2" style="text-align:center">
				  <input type="submit" value="Submit" name="btnSubmit">
				 </td>
				</tr>
				</table>
		</form>
	</div>
</div>
<?php 
	include("footer.php");
?>