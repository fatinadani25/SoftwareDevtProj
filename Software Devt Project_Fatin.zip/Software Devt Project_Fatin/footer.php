 <div id="footer">
            &copy;Copyright 2017 Footwear&nbsp;&nbsp;&nbsp;
            <a href="#" title="Privacy">Privacy</a>
            <a href="#" title="Disclaimer">Disclaimer</a>
         </div>
      </div>

   </body>
</html>