<?php
	error_reporting(E_ALL ^ E_DEPRECATED);
?>
<html>
   <head>
      <link rel="stylesheet" href="css/bootstrap.min.css"/>
      <link rel="stylesheet" href="css/mystyle.css"/>
	  <script src="js/jquery.min.js"></script>
	  <script src="js/bootstrap.min.js"></script>
	  <title>Footwear Company</title>
   </head>
   <body>
   
    <div id="wrap">
         <div id="banner">
            <img src="images/logo.jpg" alt="banner">
         </div>
         <div id="nav">
					<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="products.php">Products</a></li>
						<li><a href="about.php">About</a></li>
						<li><a href="contact.php">Contact Us</a></li>
					</ul>
						<ul role="menu" class="dropdown-menu">
								<?php
									$dbhost = "localhost";
									$dbuser = "id803784_dbadmin";
									$dbpassword = "password";
									$dbdatabase = "id803784_qu1701b_38_t0044045g_ecart";
									              
								   $db = mysql_connect($dbhost, $dbuser, $dbpassword);
								   mysql_select_db($dbdatabase, $db);
								   
								   $sql = "SELECT * FROM categories;";
								   $resultRow = mysql_query($sql);
								   
								   $categories = Array();
								   while($item = mysql_fetch_object($resultRow) ){
										array_push(	$categories,$item);
								   }
									
								   $totalSize = count($categories);
									for($i=0; $i < $totalSize; $i++) {
										$category = $categories[$i];
										echo "<li>";
										echo 	"\n<a id='' href='" . "products.php?CategoryID=" . 
												$category->id . "'>" . $category->name . "</a>";
										echo "</li>";
								   }
								?>
						</ul>
		</div>
		 

