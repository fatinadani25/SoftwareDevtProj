<?php 
	include("header.php");
?>
         <div id="main">
            <div>
               <h2>Home</h2>
               <hr/>
            </div>
            <div>
                <div id="myCarousel" class="carousel slide"
			    data-ride="carousel">
					<ol class="carousel-indicators">
						<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
						<li data-target="#myCarousel" data-slide-to="1"></li>
						<li data-target="#myCarousel" data-slide-to="2"></li>
					</ol>
					<div class="carousel-inner">
						<div class="item active">
							<img src="images/1.jpg"
							 title="Slide 1" />
						</div>
						<div class="item">
							<img src="images/2.jpg"
							 title="Slide 2" />
						</div>
						<div class="item">
							<img src="images/3.jpg"
							 title="Slide 3" />
						</div>
					</div>
					<a href="#myCarousel" data-slide="prev" 
					class="carousel-control left">
						<span class="glyphicon glyphicon-chevron-left">
						</span>
					</a>
					<a href="#myCarousel" data-slide="next" 
					class="carousel-control right">
						<span class="glyphicon glyphicon-chevron-right">
						</span>
					</a>
			   </div>
            </div>
			<h3><strong> Welcome to the Footwear Company website!</strong></h3>
			<div id="textcontent">
				<p> Having trouble getting out of the house to shop? Love free shipping? Want endless amount of shoes and only pay for a lesser price?</p>
				<p> Worry no more! Our mission is to provide our customers to the greatest convenience and to leave a great shopping experience for them. 
					All the shoes we are selling are all inspired and the quality is as amazing as the real ones, nobody would notice the difference.
					What's better than paying for branded shoes like Nike, Adidas and Timberland for only around the range of $30-$50 with free shipping? Nothing!
					So, what are you waiting for? Your dream shoes are waiting! </p>
         </div>
		</div>
<?php 
	include("footer.php");
?>

