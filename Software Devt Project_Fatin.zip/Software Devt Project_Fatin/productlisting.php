<?php
	$dbhost = "localhost";
	$dbuser = "id803784_dbadmin";
	$dbpassword = "password";
	$dbdatabase = "id803784_qu1701b_38_t0044045g_ecart";
	
	$db = mysql_connect($dbhost, $dbuser, $dbpassword);
	mysql_select_db($dbdatabase, $db);
	
	$sql = "SELECT products.*,categories.name as 'catName' FROM products " .
	       "inner join categories on products.cat_id = categories.id";
	
	$resultRow = mysql_query($sql);
	
	$products = Array();
	while($item = mysql_fetch_object($resultRow) ){
		array_push(	$products,$item);
	}

	$isAddProductButtonClicked = isset($_POST["addProduct"]);
	if($isAddProductButtonClicked == true) {
		header("location: addproductform.php");
	}
?>
<?php 
	include("header.php");
?>
  <div id="main">
	<div>
	   <h2>Products</h2>
	</div>
	<div>
		<form method="POST" action="productlisting.php">
			<input type="submit" name="addProduct" value="Add Product"></input>
		</form>
		<table class="table table-bordered">
			<tr> <!-- tr is TableRow -->
				<th>Name</th>	<!-- TH is TableHeading -->
				<th>Description</th>
				<th>Image</th>
				<th>Price</th>
				<th>Category</th>
				<th></th>
				<th></th>
			</tr>
			<?php
			    $totalSize = count($products);
				for($i=0; $i < $totalSize; $i++) {
					$product = $products[$i];
					echo "<tr>" . "\n";
					echo "\t  <td>" . "\n";
					echo "\t    " . $product->name . "\n";
					echo "\t  </td>" . "\n";
					echo "\t  <td>" . "\n";
					echo "\t    " . $product->description . "\n";
					echo "\t  </td>" . "\n";
					echo "\t  <td>" . "\n";
					echo "\t    " . "<img width='100px' height='100px' src='" . $product->image_path . "' />" . "\n";
					echo "\t  </td>" . "\n";
					echo "\t  <td>" . "\n";
					echo "\t    " . $product->price . "\n";
					echo "\t  </td>" . "\n";
					echo "\t  <td>" . "\n";
					echo "\t    " . $product->catName . "\n";
					echo "\t  </td>" . "\n";
					echo "\t	<td>" . "\n";
					echo "\t		<a href='EditProductForm.php?id=" . $product->id . "'" . ">" . "Edit" . "</a>" . "\n";
					echo "\t	</td>" . "\n";
					echo "\t	<td>" . "\n";
					echo "\t		<a href='DeleteProduct.php?id=" . $product->id . "'" . ">" . "Delete" . "</a>" . "\n";
					echo "\t	</td>" . "\n";
					echo "\t</tr>" . "\n";
				}
			?>
		</table>
	</div>
</div>
<?php include("footer.php") ?>