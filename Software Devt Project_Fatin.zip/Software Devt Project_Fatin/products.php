<?php 
	include("header.php");
?>
  <div id="main">
	<div>
	   <h2>Products</h2>
	</div>
	<div>
<?php
	$dbhost = "localhost";
	$dbuser = "id803784_dbadmin";
	$dbpassword = "password";
	$dbdatabase = "id803784_qu1701b_38_t0044045g_ecart";
		
	$db = mysql_connect($dbhost, $dbuser, $dbpassword);
	mysql_select_db($dbdatabase, $db);
	
	$categoryID = $_GET["CategoryID"];
	$sql = "SELECT * FROM products WHERE cat_id = " . $categoryID;
	$resultRow = mysql_query($sql);
	
	$products = Array();
	while($item = mysql_fetch_object($resultRow) ){
		array_push(	$products,$item);
	}
	$totalSize = count($products);

	
	if($totalSize == 0)
	{
		echo "<h1>No products</h1>";
		echo "There are no products in this category.";
	}
	else{
		echo "";
		echo "\n<table class=\"table\">";
		echo "\n<tbody>";
		for($i=0; $i < $totalSize; $i++) {
			$product = $products[$i];
			echo "\n <tr>";
			if(empty($product->image_path)) {
			  echo "\n   <td>";
			  echo "\n	  <img width='100px' height='100px' src='images/dummy.jpg' alt='" . 
						  $product->name . "' />";
			  echo "\n   </td>";
			}
			else {
			  echo "\n <td>"; 
			  echo "     <a href='" . $product->image_path . "'><img width='100px' height='100px' src='" . 
						 $product->image_path . "' alt=''   />" .
						 "</a>";
			  echo "</td>";	
			}
			echo "\n<td valign='top'>";
			echo "\n	<h3>" . $product->name . "</h3>";
			if($product->description != "") {
				echo "\n" . $product->description . "<br/>";
			}
			echo "\n	Our price:  " . "<strong>" . "$" . sprintf("%.2f", $product->price) 
				 . "</strong>" . "<br/>";
			echo "\n	" . $product->description;
			echo "\n</td>";
			echo "\n </tr>";
		}
		echo "\n  </tbody>";
		echo "\n</table>";
	}
?>
</div>
</div>
<?php 
	include('footer.php')
 ?>

